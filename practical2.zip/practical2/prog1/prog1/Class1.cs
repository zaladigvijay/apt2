﻿using System;

public class Class1
{
	static void main(String []args)
    {
        Area a = new Area();
        Console.WriteLine("Enter value of r ");
        double r = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Area of circle " + a.area(r));



    }
}
public class Area
{
    public double area(double r)
    {
        return 3.14159 * r * r;
    }
    public double area(double l,double w)
    {
        return l * w;
    }
    public double area(float a)
    {
        return a*a;
    }
    public double area(float b,float h)
    {
        return 0.5 * h * b;
    }

}
