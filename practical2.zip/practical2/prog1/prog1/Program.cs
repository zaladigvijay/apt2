﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int c;
            Console.WriteLine("Enter n");
            n=Convert.ToInt32(Console.ReadLine());

            String[] s = new String[n];
            for(int i=0;i<s.Length;i++)
            {
                Console.Write("Enter string");
                s[i] = Console.ReadLine();

            }
        
           for(int i=0;i<s.Length;i++)
              {
                c = 1;
                if(s[i] != null)
                {

               
                  for (int j=i+1;j<s.Length;j++)
                  {
                   


                        if (s[i].CompareTo(s[j]) == 0)
                        {
                            c++;
         
                            s[j] = null;

                        }
                    }
                  if(c >1 )
                    Console.WriteLine(s[i] + "=" + c);
                }
                

              }
            
  
            Console.ReadKey();
        }
    }
}
