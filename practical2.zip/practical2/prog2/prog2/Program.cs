﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog2
{
    class Program
    {
        static void Main(string[] args)
        {
            Area a = new Area();
            Console.WriteLine("Enter value of r ");
            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Area of circle " + a.area(r));

            Console.WriteLine("Enter length");
            double l = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter width");
            double w = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Area of Rectangle"+a.area(l,w));

            Console.WriteLine("Enter side value");
            float s =(float) Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Area of squaer =" + a.area(s));

            Console.WriteLine("Enter height value");
            float h = (float)Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter base value");
            float b = (float)Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Area of triangle " + a.area(h, b));
            Console.ReadKey();
        }
    }
}

public class Area
{
    public double area(double r)
    {
        return 3.14159 * r * r;
    }
    public double area(double l, double w)
    {
        return l * w;
    }
    public double area(float a)
    {
        return a * a;
    }
    public double area(float b, float h)
    {
        return 0.5 * h * b;
    }

}
