﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] a = new int[5][]
            {
                new int[]{15,12,5,20},
                new int[]{28,15,36},
                new int[]{65,32,2,36},
                new int[]{89,56,2,90},
                new int[]{101,56,2,120}

            };

            Console.WriteLine("Unsortes jagged array");
            foreach (int[] s in a)
            {
               
                foreach (int d in s)
                {
                    Console.Write(d + "   ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("sortes jagged array");
            foreach (int []s in a)
            {
                Array.Sort(s);
                foreach (int d in s)
                {
                    Console.Write(d+"   ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
