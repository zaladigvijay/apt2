﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter sizeof array");

            n = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[n];
            for(int i=0;i<n;i++)
            {
                Console.Write("a[{0}] = ", i);
                a[i] = Convert.ToInt32(Console.ReadLine());
      
            }
            getMinMax(a);
            Console.ReadKey();

        }
        public static void getMinMax(int []a)
        {
            Array.Sort(a);
            Console.WriteLine("minimum value =" + a[0]);
            Console.WriteLine("Maximum value = " + a[a.Length-1]);

        }
    }
}
